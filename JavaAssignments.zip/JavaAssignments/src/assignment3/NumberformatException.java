package assignment3;

import java.util.Scanner;

public class NumberformatException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		try
		{
		System.out.println("Please Enter your age : ");
		
		age = Integer.parseInt(sc.next());
		System.out.println("Your age is : " +age);
		} catch(NumberFormatException e)
		{
		System.out.println("The NumberFormat is Invalid.");
		System.out.println("Please enter the valid age.");
		}
	}

}
