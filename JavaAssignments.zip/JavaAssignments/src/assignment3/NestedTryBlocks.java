package assignment3;

public class NestedTryBlocks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{  
		    try{  
		     System.out.println("Nested Try");  
		     @SuppressWarnings("unused")
			int b =39/0;  
		    }catch(ArithmeticException e){System.out.println(e);}  
		   
		    try{  
		    int a[]=new int[5];  
		    a[5]=4;  
		    }catch(ArrayIndexOutOfBoundsException e){System.out.println(e);}  
		     
		    System.out.println("Dev Labs");  
		  }catch(Exception e){System.out.println("handeled");}  
		  
		  System.out.println("Java Training");
	}

}
