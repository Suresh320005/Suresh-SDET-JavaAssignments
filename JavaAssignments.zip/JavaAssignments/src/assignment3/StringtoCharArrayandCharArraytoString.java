package assignment3;

public class StringtoCharArrayandCharArraytoString {

	public static String toString(char[] a) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < a.length; i++) {
			sb.append(a[i]);
		}

		return sb.toString();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "DevLabs";

		char[] ch = new char[str.length()];

		for (int i = 0; i < str.length(); i++) {
			ch[i] = str.charAt(i);

		}

		for (char c : ch) {
			System.out.println(c);

		}
		System.out.println(toString(ch));

	}

}
