package assignment2;

public class OddNumbersfrom79to187 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.print("Odd Numbers from 79 to 187 are: ");
		for (int i = 79; i <= 187; i++) {
		   if (i % 2 != 0) {
			System.out.print("\n" +i );
		   }
		}
	}

}
