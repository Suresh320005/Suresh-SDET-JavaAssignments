package assignment1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class LeapYearcheck {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub

		BufferedReader yr = new BufferedReader(new InputStreamReader(System.in));		
		System.out.println("Enter an Year : ");
		int Year = Integer.parseInt(yr.readLine());
		if (((Year % 4 == 0) && (Year % 100 != 0)) || (Year % 400 == 0))
			System.out.println("Entered year is a leap year");
		else
			System.out.println("Entered year is not a leap year");

	}

}
