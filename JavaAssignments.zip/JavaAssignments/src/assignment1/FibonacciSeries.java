package assignment1;

public class FibonacciSeries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0, b = 1, c, i = 2, count = 10;
		System.out.print(" Fibanocci Series Number is:" + a + "\n Fibanocci Series Number is:" + b);

		while (i < count) {
			c = a + b;
			System.out.print("\n Fibanocci Series Number is:" + c);
			a = b;
			b = c;
			i++;
		}

	}

}
