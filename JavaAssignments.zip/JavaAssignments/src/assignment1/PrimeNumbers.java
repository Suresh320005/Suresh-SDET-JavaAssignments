package assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class PrimeNumbers {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		
	      int status = 1;
	      int num = 3;	      
	      BufferedReader n = new BufferedReader(new InputStreamReader(System.in));		
			System.out.println("Enter the value of n: ");
			int m = Integer.parseInt(n.readLine());
	     
	      if (m >= 1)
	      {
	         System.out.println("First " +m+" prime numbers are:");
	         
	         System.out.println(2);
	      }

	      for ( int i = 2 ; i <=m ;  )
	      {
	         for ( int j = 2 ; j <= Math.sqrt(num) ; j++ )
	         {
	            if ( num%j == 0 )
	            {
	               status = 0;
	               break;
	            }
	         }
	         if ( status != 0 )
	         {
	            System.out.println(num);
	            i++;
	         }
	         status = 1;
	         num++;
	      }         

	}

}
