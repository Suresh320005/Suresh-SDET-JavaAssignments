package assignment1;

public class sumof20naturalnumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num = 20, i = 1, sum = 0;  
		 
		while(i <= num)  
		{  
		  
		sum = sum + i;  
		
		i++;  
		}  
		 
		System.out.println("Sum of First "+num +" Natural Numbers is = " + sum);

	}

}
