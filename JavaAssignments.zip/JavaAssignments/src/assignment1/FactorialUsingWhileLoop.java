package assignment1;

public class FactorialUsingWhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x = 10;
        long fact = 1;
        int i = 1;
		while (i <= x)
        {
            fact = fact * i;
            i++;
        }
        System.out.println("Factorial of "+x+" is: "+fact);

	}

}
