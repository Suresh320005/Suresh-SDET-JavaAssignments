package assignment1;

import java.util.Arrays;

public class ArrayAscendingSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] x = {65, 189, 2, 444, 000, 109, 1009, 1334};
		 
        Arrays.sort(x);
 
        System.out.printf("Sorted Array is : %s", Arrays.toString(x));
		

	}

}
