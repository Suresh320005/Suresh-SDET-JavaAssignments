package assignment4;

public class ReverseanArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] intArray = { 50, 12, 34, 52, 11, 10, 90 };

		System.out.println("Original Array:");
		for (int i = 0; i < intArray.length; i++)
			System.out.print(intArray[i] + "  ");

		System.out.println();

		System.out.println("Original Array printed in reverse order:");
		for (int i = intArray.length - 1; i >= 0; i--)
			System.out.print(intArray[i] + "  ");
	}

}
