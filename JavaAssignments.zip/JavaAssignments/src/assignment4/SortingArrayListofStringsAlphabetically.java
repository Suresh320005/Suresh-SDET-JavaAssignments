package assignment4;

import java.util.ArrayList;
import java.util.Collections;

public class SortingArrayListofStringsAlphabetically {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str = new ArrayList<String>();
		str.add("Lab");
		str.add("Training");
		str.add("Program");
		str.add("Assignment");

		Collections.sort(str);
		System.out.println(str);
	}

}
