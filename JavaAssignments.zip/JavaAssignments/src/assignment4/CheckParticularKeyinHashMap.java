package assignment4;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class CheckParticularKeyinHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer, String> map = new HashMap<>();

		map.put(1, "Suresh");
		map.put(2, "Naresh");
		map.put(3, "Mahesh");

		int keyToBeChecked = 2;

		System.out.println("HashMap: " + map);

		Iterator<Map.Entry<Integer, String>> iterator = map.entrySet().iterator();

		boolean isKeyPresent = false;

		while (iterator.hasNext()) {

			Map.Entry<Integer, String> entry = iterator.next();

			if (keyToBeChecked == entry.getKey()) {

				isKeyPresent = true;
			}
		}

		System.out.println("key " + keyToBeChecked + " exists: " + isKeyPresent);
	}

}
